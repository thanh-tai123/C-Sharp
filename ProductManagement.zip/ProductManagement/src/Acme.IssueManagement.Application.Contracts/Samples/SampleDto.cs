﻿namespace Acme.IssueManagement.Samples;

public class SampleDto
{
    public int Value { get; set; }
}
