﻿namespace Acme.IssueManagement;

public class IssueManagementRemoteServiceConsts
{
    public const string RemoteServiceName = "IssueManagement";

    public const string ModuleName = "issueManagement";
}
