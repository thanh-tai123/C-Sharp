﻿namespace Acme.IssueManagement;

public static class IssueManagementErrorCodes
{
    //Add your business exception error codes here...
}
