﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Acme.IssueManagement.Books
{
    public enum BookType
    {
        Horror,
        Adventure
    }
}
