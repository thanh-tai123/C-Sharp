﻿using Volo.Abp.Localization;

namespace Acme.IssueManagement.Localization;

[LocalizationResourceName("IssueManagement")]
public class IssueManagementResource
{

}
