﻿using Volo.Abp.Settings;

namespace Acme.IssueManagement.Settings;

public class IssueManagementSettingDefinitionProvider : SettingDefinitionProvider
{
    public override void Define(ISettingDefinitionContext context)
    {
        /* Define module settings here.
         * Use names from IssueManagementSettings class.
         */
    }
}
