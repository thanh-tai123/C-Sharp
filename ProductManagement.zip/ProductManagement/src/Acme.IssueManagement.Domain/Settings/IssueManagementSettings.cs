﻿namespace Acme.IssueManagement.Settings;

public static class IssueManagementSettings
{
    public const string GroupName = "IssueManagement";

    /* Add constants for setting names. Example:
     * public const string MySettingName = GroupName + ".MySettingName";
     */
}
